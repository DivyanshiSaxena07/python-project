# this is my first python programe
a = '''Lorem ipsum dolor sit amet,
consectetur adipiscing elit,
sed do eiusmod tempor incididunt
ut labore et dolore magna aliqua.'''
# a="harry"
# print(a[-4:-2])
print(a)
#for c in a: