text=input("Enter text here")
# print(text[::-1])

# for line in text.split('\n'):
#  print(' '.join(line.split()[::-1]))
# count=0
# for char in text:
#  count+=1  
  
# print(count)
