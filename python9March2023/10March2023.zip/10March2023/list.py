# write a Python program to swap first and last element of the list.
# lst=[10,20,30,40,50]
# size=len(lst)

# temp=lst[0]
# lst[0]=lst[size-1]
# lst[size-1]=temp

# print(lst)

# lst=[10,20,30,40,50]
# lst[0],lst[-1]=lst[-1],lst[0]
# print(lst);

# Python program to swap two elements 
# a=10
# b=20
# print("Before swapping:","a=",a," b=",b)
# a,b=b,a
# print("Before swapping:","a=",a," b=",b)

