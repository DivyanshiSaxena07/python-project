# print(bool("abc"))
# function in python 
def welcome(name):
    print(f"{name},Welcom in tout")
    
welcome("divyanshi")