# 1 False
# print (5 == 10)
# 2 def
# def welcome(name):
#        print (f"{name}, Welcome to Flexiple")

# welcome ("Ben")
# 3 if
# age=18
# if age>18:
#        print("You are eligible for voting")
# else:
#        print("you are not eligible")
# 4 raise:-it raise an error
# name="harry" 
# if not type(name) is int:
#        raise TypeError("Only integers are allow ")
# 5 None
# print(type(None))
# 6
# del
# The del statement is used to delete an object in Python.
# name = ["Ben", "Nick", "Steph"]
# del name[1]
# print (name)
# import datetime as dl

# today = dl.date.today()
# print(today)

# import keyword
# print (keyword.kwlist)

a=(10,)
a={}
print(type(a))
