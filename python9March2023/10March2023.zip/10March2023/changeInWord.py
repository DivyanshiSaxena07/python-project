# digit=["Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine"]
# num=input("Enter number")

# digits = {'1':'One','2':'Two','3':'Three','4':'Four','5':'Five','6':'Six','7':'Seven','8':'Eight','9':'Nine','0':'Zero'}
# for number in num:
#         print(digits[number] , end = ' ')



# Read two numbers from the keyboard and print minimum value
# a=int(input("Enter number"))
# b=int(input("ENter second number"))
# min=a if a<b else b
# print(min)

# Read two numbers from the keyboard and print maximum value
# a=int(input("ENter First Number"))
# b=int(input("ENter Second number"))
# max=a if a>b else b
# print(max)

