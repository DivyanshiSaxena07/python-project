# i=1
# while i<2:
#     print(i)
#     i+=1;
# else:
#     print("Condition false")

# l=[1,2,4,5]
# print(l)

# a,b,c=10,20,30
# # print(a,b,c,sep=":")
# # print("hello"world")

# a,b,c=10,20.0,"hello"
# # print("name is",c,"age is",a,"height is",b)
# print("name is %s age is %d height is %f"%(c,a,b))

# from sys import argv

# print(argv[1])

# print("hello ")
# print()
# print("nitesh")

# print("hello ",end='')
# print("jayesh")
# a="ssah"
# print(id(a))

# print(int(123.987))
 
# print(int(10+5j))

# print(int(True))

# print(int(False))

# print(int("10"))

# print(int("10.5"))

# print(int("ten"))

# print(int("0B1111"))
# for arr in range(0,9):
#  print(arr)


for i in range(0,5):
    for j in range(0,i+1):
        print("*",end=" ")
    print()     