from p1.module1 import f1
f1()