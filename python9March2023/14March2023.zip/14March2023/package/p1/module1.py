def f1():
 print("Hello this is from module1 present in com")