f=open("abc.txt","w")
f.write("hello this is my filehandling file")
# print("File Name: ",f.name)
# print("File Mode: ",f.mode)
# print("Is File Readable: ",f.readable())
# print("Is File Writable: ",f.writable())
# print("Is File Closed : ",f.closed)
# f.close()
# print("Is File Closed : ",f.closed)

# lst=["sunny","Money","bunny"]#sunnyMoneybunny
# f.writelines(lst)
# # f.write(lst)
# lst=["sunny\n","Money\n","bunny\n"]
# f=open("abc.txt","r")
# print(f.read())
# to read only 10 character
# data=f.read(10)
# print(data)

# line1=f.readline()
# print(line1,end='')
# line2=f.readline()
# print(line2,end='')
# line3=f.readline()
# print(line3,end='')

# sunny
# Money
# bunny

# with open("acb.txt","w")as f:
#     f.write("hii durga")


# f=open("abc.txt","r")
# print(f.tell())
# print(f.read(2))
# print(f.tell())
# print(f.read(3))
# print(f.tell())

# data="All Students are STUPIDS"
# f=open("abc.txt","w")
# f.write(data)
# with open("abc.txt","r+") as f:
#  text=f.read()
#  print(text)
#  print("The Current Cursor Position: ",f.tell())
#  f.seek(17)
#  print("The Current Cursor Position: ",f.tell())
#  f.write("GEMS!!!")
#  f.seek(0)
#  text=f.read()
#  print("Data After Modification:")
#  print(text)
  
  

# f=open("abcd.txt","a")
# ("hii this is me")


# import os 
# print(os.path.isfile("abc.txt"))

# f1=open("rossum.jpg","rb")