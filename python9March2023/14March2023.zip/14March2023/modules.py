# import time
# from imp import reload
# import decoratorFunction
# time.sleep(30)
# reload(decoratorFunction)
# time.sleep(30)
# reload(decoratorFunction)
# print("This is test file")
# print(dir())


# print(__builtins__ )
# print(__cached__ )
# print(__doc__)
# print(__file__)
# print(__loader__)
# print(__name__)
# print(__package__)
# print(__spec__)


# 1. sqrt(x)
# 2. ceil(x)
# 3. floor(x)
# 4. fabs(x)
# 5.log(x)
# 6. sin(x)
# 7. tan(x)

import math
from random import*

# print(help(math))
# print(math.sqrt(4))
# print(math.ceil(-4.2))
# print(math.ceil(4.2))
# print(math.ceil(4.0))
# print(math.floor(10.1))
# print(math.fabs(-4.2))
# print(math.log( 4.2))
# print(math.sin(-4.2))
# print(math.tan(-4.2))

print(random())
print(randint(1,100))
print(uniform(1,100))
# print(choice(10))