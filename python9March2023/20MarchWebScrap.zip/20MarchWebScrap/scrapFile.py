import requests,json
from bs4 import BeautifulSoup
r=requests.get("https://www.bookswagon.com/book/lifes-amazing-secrets-gaur-gopal/9780143442295")

def getData():
    soup=BeautifulSoup(r.content,'html.parser')
    s = soup.find('div', class_="container mt-2 pt-3 pb-1 product-detailwrapper").findAll('p')
    bookNo,status,price,Language,bookName,authorName=[],[],[],[],[],[]
    for l in s:
        bookNo.append(l.find('span',class_="booktitle font-weight-bold"))
        status.append(l.find('span',class_='booktitle font-weight-bold'))
        price.append(l.find('span',class_='booktitle font-weight-bold'))
        Language.append(l.find('span',class_='booktitle font-weight-bold'))
        bookName.append(l.find('span',class_='booktitle font-weight-bold'))
        authorName.append(l.find('span',class_='author authortextcolor'))
    
    dict={}
    list1=[]
    for a,b,c,d,e,f in zip(bookNo,status,price,Language,bookName,authorName):
        dict["bookNo"]=a
        # j=j[1:5]
        # j=int(j)
        dict["status"]=b
        dict["price"]=c
        dict["Language"]=d
        dict["bookName"]=e
        dict["authorName"]=f
        
        list1.append(dict.copy())
        f=open("scrap.json","w")
        json.dump(list1,f,indent=4)
        f.close()
        return(list1)
demo=getData()     
print(demo)       
        
            
            
            
        
        