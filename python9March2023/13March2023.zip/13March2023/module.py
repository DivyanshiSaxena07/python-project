# import function
# print(function.z)

# module aliasing
import function as f
print(f.z)