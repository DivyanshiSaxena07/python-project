# Exercise 1: Print First 10 natural numbers using while loop
# i=1
# while i<10:
#     print(i)
#     i+=1
 
# for i in range(1,5):
#     for j in range(1,i+1):
#         print(j,end=" ")
#     print()


# for i in range(1,5):
#     for j in range(1,i+1):
#         print("*",end=" ")
#     print()
    
    
    
# i = 1
# while i < 6:
#   print(i)
#   if i == 3:
#     break
#   i += 1

# i = 0
# while i < 6:
#   i += 1
#   if i == 3:
#     continue
#   print(i)

i = 1
while i < 6:
  print(i)
  i += 1
else:
  print("i is no longer less than 6")