a=28
b=10
c=30
# if a>b:
#     print("a is greater")
# else:
#     print("b is greater")

# print("a is greater") if a<b else print("b is greater")

# print("both condition  are satisfied") if a>b and a>c else print("both condition are not satisfied")

# print("one condition are true") if a>b or a>c else print("both condition are true")

# if not a<b:
#     print("condition true")

# if a>20:
#     print("Above 20")
#     if b==18:
#         print("Equal")
#     else:
#         print("May be greter than 18 or less than 18")        