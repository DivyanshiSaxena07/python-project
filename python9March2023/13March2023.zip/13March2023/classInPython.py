# class MyClass:
#     x=10
#     print(x)#10
    
# print(MyClass)#<class '__main__.MyClass'>

# create an object in python
# class MyClass:
#     x=10
    
# p1=MyClass()
# print(p1.x)

# __init__() function
# class Person:
#     def __init__(self,name,age):
#         self.name=name
#         self.age=age
# p1=Person("jony",23)
# print(p1.name)
# print(p1.age)