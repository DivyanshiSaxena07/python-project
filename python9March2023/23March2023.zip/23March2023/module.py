# from datetime import date,time
# today = date.today()
# t=time(11,22,33)
# print("Current year:",today.year)
# print("Current month:",today.month)
# print("Current date:",today.day)
# print("Current time:",t)


# from emoji import emojize
# print(emojize(":thumbs_up:"))


# import emojis
# emojified = emojis.encode("There is a :boom: in my boot !")
# print(emojified)

# import pandas as ps
# pf=ps.read_csv('data.csv')
# print(pf.to_string())
# val={
#     'cars':['BMW','Volvo','Ford'],
#     'rating':[3,5,2]
# }
# myval=ps.DataFrame(val)
# myval=ps.DataFrame(val,index=[1,2,3])
# print(myval)
# print(ps.__version__)
# myvalue=ps.Series(val['rating'])
# print(myvalue)

